/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
}

// module.exports = {
//   env: {
//     BACKEND_URL: process.env.NEXT_PUBLIC_BACKEND_URL
//   },
// }

module.exports = nextConfig
