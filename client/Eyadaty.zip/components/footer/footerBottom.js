import React from "react";

const FooterBottom = () => {
    return(
        <>
            <div className={"flex items-center justify-center"}>
                <span className={"text-light__gray__color text-sm"}>Tous Les Droits Sont Réservés Pour Ce Site </span>
            </div>
        </>
    )
}
export default FooterBottom
