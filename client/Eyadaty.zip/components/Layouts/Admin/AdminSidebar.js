import Image from 'next/image'
import React from 'react'
import EyedatyLogo from '../../Home/eyedatyLogo'
import TwoCircle from "../../../assets/TwoCircle.svg"
import Logout from "../../../assets/Logout.svg"
import Link from 'next/link'
import { useRouter } from 'next/router'
import HomeIcon from '../../../icons/homeIcons'
import DocumentIcon from '../../../icons/documentIcon'
import UserIcon from '../../../icons/userIcon'
import EditIcon from '../../../icons/editIcon'
import PlusIcon from '../../../icons/plusIcon'

const AdminSidebar = () => {
    const router = useRouter();

    return (
        <div className='AdminSidebar px-2 pt-4' style={{ height: "100vh" }}>
            <div className='flex justify-between items-center'>
                <EyedatyLogo />
                <div>
                    <Image src={TwoCircle} alt="Two Circles" />
                </div>
            </div>
            <div>
                <div className='mt-8 relative'>
                    <div className='mb-6'>
                        <Link href="/admin">
                            <button className={`${router.pathname === "/admin" ? "hyperlink text-[#0094DA] flex gap-3 items-center" : "flex gap-3 items-center text-[#65737E]"}`}>
                                <HomeIcon />
                                <span>Panneau de contrôle</span>
                            </button>
                        </Link>
                    </div>
                    <div className='mb-6'>
                        <Link href="/admin/pages">
                            <button className={`${router.pathname === "/admin/pages" ? "hyperlink text-[#0094DA] flex gap-3 items-center" : "flex gap-3 items-center text-[#65737E]"}`}>
                                <DocumentIcon />
                                <span>Les pages</span>
                            </button>
                        </Link>
                    </div>
                    <div className='mb-6'>
                        <Link href="/admin/users">
                            <button className={`${router.pathname === "/admin/users" ? "hyperlink text-[#0094DA] flex gap-3 items-center" : "flex gap-3 items-center text-[#65737E]"}`}>
                                <UserIcon />
                                <span>Utilisateurs</span>
                            </button>
                        </Link>
                    </div>
                    <div className='mb-6'>
                        <Link href="/admin/articles">
                            <button className={`${router.pathname === "/admin/articles" ? "hyperlink text-[#0094DA] flex gap-3 items-center" : "flex gap-3 items-center text-[#65737E]"}`}>
                                <EditIcon />
                                <span>Articles</span>
                            </button>
                        </Link>
                    </div>
                    <div className='mb-6'>
                        <Link href="/admin/create-page">
                            <button className={`${router.pathname === "/admin/create-page" ? "hyperlink text-[#0094DA] flex gap-3 items-center" : "flex gap-3 items-center text-[#65737E]"}`}>
                                <PlusIcon />
                                <span>Créer un page</span>
                            </button>
                        </Link>
                    </div>
                </div>
                <div className='absolute top-[90%] w-full left-0 px-2'>
                    <button className='gap-4 rounded-[12px] border border-[#FF6551] h-[48px] w-full flex justify-center items-center text-[#FF6551] text-[16px] font-[500]'>
                        <span className='text-[#FF6551] '>Déconnexion</span>
                        <Image src={Logout} alt="Logout" />
                    </button>
                </div>
            </div>
        </div>
    )
}

export default AdminSidebar
